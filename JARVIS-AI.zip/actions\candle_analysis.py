
import json
import time
import urllib.request
import urllib.parse
from datetime import datetime, timezone

SYMBOLS = {
    "GBP/USD": "GBPUSD=X",
    "EUR/USD": "EURUSD=X",
    "USD/JPY": "JPY=X",
    "AUD/USD": "AUDUSD=X",
    "USD/CHF": "CHF=X",
    "USD/CAD": "CAD=X",
    "NZD/USD": "NZDUSD=X",
    "EUR/GBP": "EURGBP=X",
    "GBP/JPY": "GBPJPY=X",
    "BTC": "BTC-USD",
    "BITCOIN": "BTC-USD",
    "ETH": "ETH-USD",
    "ETHEREUM": "ETH-USD",
    "SOL": "SOL-USD",
    "XRP": "XRP-USD",
    "GOLD": "GC=F",
}

INTERVALS = {
    "1 minute": ("1m", "1d", 60),
    "1m": ("1m", "1d", 60),
    "5 minutes": ("5m", "5d", 300),
    "5m": ("5m", "5d", 300),
    "15 minutes": ("15m", "5d", 900),
    "15m": ("15m", "5d", 900),
    "30 minutes": ("30m", "1mo", 1800),
    "30m": ("30m", "1mo", 1800),
    "1 hour": ("1h", "1mo", 3600),
    "1h": ("1h", "1mo", 3600),
    "1 day": ("1d", "3mo", 86400),
    "1d": ("1d", "3mo", 86400),
}


def _ema(values, period):
    if len(values) < period:
        return None
    result = sum(values[:period]) / period
    multiplier = 2 / (period + 1)
    for value in values[period:]:
        result = (value * multiplier) + (result * (1 - multiplier))
    return result


def _rsi(values, period=14):
    if len(values) <= period:
        return None
    changes = [values[i] - values[i - 1] for i in range(1, len(values))]
    gains = [max(change, 0) for change in changes[-period:]]
    losses = [max(-change, 0) for change in changes[-period:]]
    avg_gain = sum(gains) / period
    avg_loss = sum(losses) / period
    if avg_loss == 0:
        return 100.0
    return 100 - (100 / (1 + avg_gain / avg_loss))


def candle_analysis(parameters: dict, player=None) -> str:
    symbol_input = str(parameters.get("symbol", "GBP/USD")).strip().upper()
    interval_input = str(parameters.get("interval", "5 minutes")).strip().lower()

    symbol = SYMBOLS.get(symbol_input, symbol_input)
    interval_info = INTERVALS.get(interval_input)

    if not interval_info:
        return "Please choose 1 minute, 5 minutes, 15 minutes, 30 minutes, 1 hour, or 1 day."

    interval, period_range, seconds = interval_info

    if not symbol or len(symbol) > 30:
        return "Please provide a valid market symbol, such as GBP/USD or BTC."

    url = (
        "https://query1.finance.yahoo.com/v8/finance/chart/"
        + urllib.parse.quote(symbol, safe="=")
        + f"?range={period_range}&interval={interval}"
    )

    request = urllib.request.Request(
        url,
        headers={"User-Agent": "Mozilla/5.0"}
    )

    try:
        with urllib.request.urlopen(request, timeout=15) as response:
            data = json.loads(response.read().decode("utf-8"))

        chart = data.get("chart", {})
        if chart.get("error"):
            return f"Market data provider error: {chart['error']}"

        result = chart.get("result")
        if not result:
            return f"No recent market data found for {symbol_input}."

        item = result[0]
        timestamps = item.get("timestamp") or []
        quote = item.get("indicators", {}).get("quote", [{}])[0]
        closes = quote.get("close") or []
        highs = quote.get("high") or []
        lows = quote.get("low") or []
        opens = quote.get("open") or []

        candles = []
        now = time.time()

        for i, stamp in enumerate(timestamps):
            if i >= len(closes) or closes[i] is None:
                continue
            if i >= len(opens) or opens[i] is None:
                continue
            if i >= len(highs) or highs[i] is None:
                continue
            if i >= len(lows) or lows[i] is None:
                continue

            # Ignore a candle that is still forming.
            if stamp + seconds > now:
                continue

            candles.append((
                float(opens[i]),
                float(highs[i]),
                float(lows[i]),
                float(closes[i])
            ))

        if len(candles) < 22:
            return "Not enough completed candles are available yet. Try a longer interval."

        values = [c[3] for c in candles]
        latest = values[-1]
        previous = values[-2]

        ema9 = _ema(values, 9)
        ema21 = _ema(values, 21)
        rsi = _rsi(values)

        recent_move = latest - values[-4]
        previous_move = values[-1] - values[-2]

        votes_up = 0
        votes_down = 0
        reasons = []

        if ema9 is not None and ema21 is not None:
            if ema9 > ema21:
                votes_up += 1
                reasons.append("short EMA is above long EMA")
            elif ema9 < ema21:
                votes_down += 1
                reasons.append("short EMA is below long EMA")

        if latest > previous:
            votes_up += 1
            reasons.append("latest completed candle closed higher")
        elif latest < previous:
            votes_down += 1
            reasons.append("latest completed candle closed lower")

        if recent_move > 0:
            votes_up += 1
            reasons.append("recent price momentum is positive")
        elif recent_move < 0:
            votes_down += 1
            reasons.append("recent price momentum is negative")

        if rsi is not None:
            if 50 < rsi < 70:
                votes_up += 1
                reasons.append("RSI supports upward momentum")
            elif 30 < rsi < 50:
                votes_down += 1
                reasons.append("RSI supports downward momentum")
            elif rsi >= 70 or rsi <= 30:
                reasons.append("RSI is at an extreme; reversal risk is higher")

        difference = abs(votes_up - votes_down)
        total_votes = votes_up + votes_down

        if difference < 2 or total_votes < 3:
            signal = "WAIT"
            strength = "Weak or mixed"
        elif votes_up > votes_down:
            signal = "UP"
            strength = "Moderate" if difference == 2 else "Stronger"
        else:
            signal = "DOWN"
            strength = "Moderate" if difference == 2 else "Stronger"

        try:
            price_text = f"{latest:.6f}"
        except Exception:
            price_text = str(latest)

        checked = datetime.now(timezone.utc).strftime("%H:%M:%S UTC")
        reason_text = "; ".join(reasons) if reasons else "No clear technical agreement"

        return (
            f"MARKET: {symbol_input} ({symbol})\n"
            f"INTERVAL: {interval_input}\n"
            f"LAST COMPLETED CLOSE: {price_text}\n"
            f"NEXT CANDLE ESTIMATE: {signal}\n"
            f"SIGNAL STRENGTH: {strength}\n"
            f"INDICATORS: {votes_up} upward votes, {votes_down} downward votes\n"
            f"RSI: {rsi:.1f}\n"
            f"REASON: {reason_text}\n"
            f"DATA CHECKED: {checked}\n"
            "WARNING: This is a technical estimate, not a guaranteed prediction. "
            "A candle can move either way. WAIT means the indicators disagree."
        )

    except Exception as exc:
        return (
            f"Could not retrieve live candle data for {symbol_input}: {exc}. "
            "The market-data provider may be unavailable or rate-limiting requests."
        )


TOOL = {
    "name": "candle_analysis",
    "description": (
        "Analyses recent completed live market candles and estimates whether the "
        "NEXT candle may go UP, DOWN, or WAIT. Use whenever the user asks about "
        "the next candle, market direction, GBP/USD, EUR/USD, forex, Bitcoin, "
        "Ethereum, Solana, XRP, or gold. Always call this tool for a fresh "
        "technical estimate instead of guessing. This is not a guaranteed prediction."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "symbol": {
                "type": "STRING",
                "description": "Market symbol, e.g. GBP/USD, EUR/USD, BTC, ETH, SOL, XRP, GOLD."
            },
            "interval": {
                "type": "STRING",
                "description": "Candle interval: 1 minute, 5 minutes, 15 minutes, 30 minutes, 1 hour, or 1 day."
            }
        },
        "required": ["symbol"]
    },
    "handler": candle_analysis
}
