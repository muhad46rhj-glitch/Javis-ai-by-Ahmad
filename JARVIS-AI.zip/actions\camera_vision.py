﻿from pathlib import Path
from datetime import datetime
import base64
import json
import time
import urllib.request
import urllib.error

import cv2


def camera_vision_action(parameters: dict, player=None, session_memory=None) -> str:
    camera = None

    try:
        print("[Camera] Opening webcam. Camera is active only for this snapshot.")

        camera = cv2.VideoCapture(0, cv2.CAP_DSHOW)

        if not camera.isOpened():
            return "Sir, I could not open your webcam. Please check that it is connected and not being used by another application."

        time.sleep(0.7)
        success, frame = camera.read()

        if not success or frame is None:
            return "Sir, the webcam opened, but I could not capture an image."

        success, encoded_image = cv2.imencode(
            ".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), 85]
        )

        if not success:
            return "Sir, I could not prepare the camera image."

        image_data = base64.b64encode(encoded_image.tobytes()).decode("utf-8")

    except Exception as error:
        return f"Sir, there was a camera error: {error}"

    finally:
        if camera is not None:
            camera.release()

    question = parameters.get(
        "question",
        "Describe the visible person and surroundings. Mention visible clothing, hairstyle, and objects. Do not guess the person's identity."
    )

    payload = {
        "model": "moondream",
        "prompt": str(question),
        "images": [image_data],
        "stream": False
    }

    request = urllib.request.Request(
        "http://127.0.0.1:11434/api/generate",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST"
    )

    try:
        with urllib.request.urlopen(request, timeout=120) as response:
            result = json.loads(response.read().decode("utf-8"))

        description = result.get("response", "").strip()

        if not description:
            return "Sir, Moondream received the image but did not return a description."

        message = "I have looked through your webcam. " + description
        print("[Camera Vision]", message)
        return message

    except urllib.error.URLError as error:
        return f"Sir, I captured the image, but could not contact Ollama. Please make sure Ollama is running. Details: {error}"
    except Exception as error:
        return f"Sir, image analysis failed: {error}"


TOOL = {
    "name": "camera_vision",
    "description": "When the user asks JARVIS to look at them or see what is in front of the webcam, capture one webcam snapshot and use the local Moondream vision model to describe visible details. Only activate the camera when explicitly requested.",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "question": {
                "type": "STRING",
                "description": "What to describe in the webcam image. Optional."
            }
        },
        "required": []
    },
    "handler": camera_vision_action,
}
