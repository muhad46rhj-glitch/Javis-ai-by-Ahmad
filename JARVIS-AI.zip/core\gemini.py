﻿import json
import re
import ollama
from pathlib import Path

FAST = "fast"
SMART = "smart"
SEARCH = "search"

_KEY_FILE = Path(__file__).resolve().parent.parent / "config" / "api_keys.json"


def ollama_config():
    try:
        from memory.config_manager import get_provider_config
        cfg = get_provider_config("openai_compat@ollama")
        return {
            "host": cfg.get("base_url", "http://127.0.0.1:11434/v1").replace("/v1", ""),
            "model": cfg.get("model", "llama3.2")
        }
    except Exception:
        return {
            "host": "http://127.0.0.1:11434",
            "model": "llama3.2"
        }


class _Reply:
    __slots__ = ("text",)

    def __init__(self, text):
        self.text = text


def call(contents, tier=SMART, config=None, timeout_ms=30000,
         key="", provider=""):
    cfg = ollama_config()
    client = ollama.Client(host=cfg["host"])

    if isinstance(contents, list):
        prompt = "\n".join(str(x) for x in contents)
    else:
        prompt = str(contents)

    response = client.chat(
        model=cfg["model"],
        messages=[{"role": "user", "content": prompt}]
    )

    return _Reply(response["message"]["content"])


def text(contents, tier=SMART, config=None, timeout_ms=30000,
         key="", default=""):
    try:
        return call(contents, tier, config, timeout_ms, key).text
    except Exception:
        return default


def parse_json(contents, default=None):
    try:
        if isinstance(contents, _Reply):
            contents = contents.text

        if isinstance(contents, dict):
            return contents

        if isinstance(contents, list):
            contents = "\n".join(str(x) for x in contents)

        raw = str(contents).strip()
        raw = re.sub(r"^```(?:json)?\s*", "", raw)
        raw = re.sub(r"\s*```$", "", raw)

        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            match = re.search(r"\{.*\}|\[.*\]", raw, re.DOTALL)
            if match:
                return json.loads(match.group(0))
    except Exception:
        pass

    return {} if default is None else default


def live_model():
    raise RuntimeError(
        "Gemini Live is disabled. Select the local Ollama pipeline."
    )


def note_live_failure(live_model_name, error):
    return False
